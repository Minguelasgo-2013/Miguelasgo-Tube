#!/usr/bin/env python3
"""
Miguelasgo Tube - Servidor local (sin dependencias externas)
==============================================================
Usa SOLO la librería estándar de Python (http.server, socketserver,
json, etc.) — no necesita pip, Flask ni permisos de administrador.
Pensado para correr desde un pen drive y servir vídeos a cualquier
dispositivo conectado a la misma red local (WiFi/LAN).

Uso:
    python3 server.py

Luego abre desde cualquier dispositivo de tu red:
    http://<IP-DE-ESTE-PC>:8000

Estructura de carpetas (se crean solas si no existen):
    /videos     -> archivos de vídeo subidos
    /static     -> index.html, css, js del frontend
    /data.json  -> base de datos simple en JSON (título, descripción, etc.)
"""

import json
import mimetypes
import os
import re
import socket
import time
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse, parse_qs, unquote

# ── CONFIGURACIÓN ─────────────────────────────────────────────
BASE_DIR = Path(__file__).resolve().parent
VIDEOS_DIR = BASE_DIR / "videos"
STATIC_DIR = BASE_DIR / "static"
DATA_FILE = BASE_DIR / "data.json"

EXTENSIONES_PERMITIDAS = {".mp4", ".webm", ".mov", ".mkv", ".avi", ".ogg"}
LIMITE_TAMANO_MB = 500
PUERTO = 8000

VIDEOS_DIR.mkdir(exist_ok=True)
STATIC_DIR.mkdir(exist_ok=True)


# ── BASE DE DATOS SIMPLE (JSON) ───────────────────────────────
def cargar_datos():
    if not DATA_FILE.exists():
        return {"videos": []}
    try:
        with open(DATA_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError):
        return {"videos": []}


def guardar_datos(datos):
    with open(DATA_FILE, "w", encoding="utf-8") as f:
        json.dump(datos, f, ensure_ascii=False, indent=2)


def obtener_ip_local():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
    except OSError:
        ip = "127.0.0.1"
    finally:
        s.close()
    return ip


# ── HELPERS HTTP ───────────────────────────────────────────────
def es_nombre_seguro(nombre):
    """Evita path traversal: solo permite nombres de archivo simples."""
    return bool(re.match(r'^[a-zA-Z0-9_\-]+\.[a-zA-Z0-9]+$', nombre))


class TubeHandler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    # Silencia el logging por defecto (lo hacemos nosotros, más limpio)
    def log_message(self, formato, *args):
        print(f"  {self.address_string()} - {formato % args}")

    # ── Utilidades de respuesta ──────────────────────────────
    def enviar_json(self, datos, status=200):
        cuerpo = json.dumps(datos, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(cuerpo)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(cuerpo)

    def enviar_error_json(self, mensaje, status=400):
        self.enviar_json({"error": mensaje}, status=status)

    def enviar_archivo(self, ruta, content_type=None, descargar_nombre=None):
        if not ruta.exists() or not ruta.is_file():
            self.enviar_error_json("Archivo no encontrado.", 404)
            return

        tamano_total = ruta.stat().st_size
        if content_type is None:
            content_type, _ = mimetypes.guess_type(str(ruta))
            content_type = content_type or "application/octet-stream"

        rango = self.headers.get("Range")
        if rango and rango.startswith("bytes="):
            # Soporte de range requests para que el <video> pueda hacer seek
            try:
                inicio_str, fin_str = rango.replace("bytes=", "").split("-")
                inicio = int(inicio_str) if inicio_str else 0
                fin = int(fin_str) if fin_str else tamano_total - 1
                fin = min(fin, tamano_total - 1)
                longitud = fin - inicio + 1

                self.send_response(206)
                self.send_header("Content-Type", content_type)
                self.send_header("Content-Range", f"bytes {inicio}-{fin}/{tamano_total}")
                self.send_header("Accept-Ranges", "bytes")
                self.send_header("Content-Length", str(longitud))
                self.end_headers()

                with open(ruta, "rb") as f:
                    f.seek(inicio)
                    restante = longitud
                    bloque = 1024 * 256
                    while restante > 0:
                        leido = f.read(min(bloque, restante))
                        if not leido:
                            break
                        self.wfile.write(leido)
                        restante -= len(leido)
                return
            except (BrokenPipeError, ConnectionResetError):
                return
            except Exception:
                pass  # si algo falla con el range, servimos completo abajo

        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Accept-Ranges", "bytes")
        self.send_header("Content-Length", str(tamano_total))
        if descargar_nombre:
            self.send_header("Content-Disposition", f'inline; filename="{descargar_nombre}"')
        self.end_headers()

        try:
            with open(ruta, "rb") as f:
                while True:
                    bloque = f.read(1024 * 256)
                    if not bloque:
                        break
                    self.wfile.write(bloque)
        except (BrokenPipeError, ConnectionResetError):
            pass  # el cliente cortó la conexión (normal al hacer seek), no es un error real

    # ── GET ───────────────────────────────────────────────────
    def do_GET(self):
        parsed = urlparse(self.path)
        ruta = unquote(parsed.path)
        query = parse_qs(parsed.query)

        try:
            if ruta == "/" or ruta == "":
                self.enviar_archivo(STATIC_DIR / "index.html", "text/html; charset=utf-8")
                return

            if ruta.startswith("/static/"):
                nombre = ruta[len("/static/"):]
                if not es_nombre_seguro(nombre.replace("/", "_")) and "/" in nombre:
                    self.enviar_error_json("Ruta no válida.", 400)
                    return
                self.enviar_archivo(STATIC_DIR / nombre)
                return

            if ruta.startswith("/videos/"):
                nombre = ruta[len("/videos/"):]
                if not es_nombre_seguro(nombre):
                    self.enviar_error_json("Nombre de archivo no válido.", 400)
                    return
                self.enviar_archivo(VIDEOS_DIR / nombre)
                return

            if ruta == "/api/videos":
                datos = cargar_datos()
                videos = datos.get("videos", [])

                busqueda = (query.get("q", [""])[0]).strip().lower()
                categoria = (query.get("categoria", [""])[0]).strip()

                resultado = videos
                if busqueda:
                    resultado = [
                        v for v in resultado
                        if busqueda in v.get("titulo", "").lower()
                        or busqueda in v.get("descripcion", "").lower()
                    ]
                if categoria and categoria.lower() != "todos":
                    resultado = [v for v in resultado if v.get("categoria") == categoria]

                resultado = sorted(resultado, key=lambda v: v.get("fecha", 0), reverse=True)
                self.enviar_json(resultado)
                return

            m = re.match(r'^/api/videos/([a-zA-Z0-9]+)$', ruta)
            if m:
                video_id = m.group(1)
                datos = cargar_datos()
                video = next((v for v in datos.get("videos", []) if v["id"] == video_id), None)
                if not video:
                    self.enviar_error_json("Vídeo no encontrado.", 404)
                    return
                self.enviar_json(video)
                return

            self.enviar_error_json("Ruta no encontrada.", 404)

        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception as e:
            try:
                self.enviar_error_json(f"Error interno: {e}", 500)
            except Exception:
                pass

    # ── POST ──────────────────────────────────────────────────
    def do_POST(self):
        parsed = urlparse(self.path)
        ruta = unquote(parsed.path)

        try:
            if ruta == "/api/videos":
                self.manejar_subida_video()
                return

            m = re.match(r'^/api/videos/([a-zA-Z0-9]+)/vista$', ruta)
            if m:
                video_id = m.group(1)
                datos = cargar_datos()
                video = next((v for v in datos.get("videos", []) if v["id"] == video_id), None)
                if not video:
                    self.enviar_error_json("Vídeo no encontrado.", 404)
                    return
                video["vistas"] = video.get("vistas", 0) + 1
                guardar_datos(datos)
                self.enviar_json({"vistas": video["vistas"]})
                return

            m = re.match(r'^/api/videos/([a-zA-Z0-9]+)/like$', ruta)
            if m:
                video_id = m.group(1)
                datos = cargar_datos()
                video = next((v for v in datos.get("videos", []) if v["id"] == video_id), None)
                if not video:
                    self.enviar_error_json("Vídeo no encontrado.", 404)
                    return

                longitud = int(self.headers.get("Content-Length", 0))
                incremento = 1
                if longitud > 0:
                    cuerpo = self.rfile.read(longitud)
                    try:
                        payload = json.loads(cuerpo)
                        incremento = int(payload.get("incremento", 1))
                    except (json.JSONDecodeError, ValueError, TypeError):
                        incremento = 1

                video["likes"] = max(0, video.get("likes", 0) + incremento)
                guardar_datos(datos)
                self.enviar_json({"likes": video["likes"]})
                return

            self.enviar_error_json("Ruta no encontrada.", 404)

        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception as e:
            try:
                self.enviar_error_json(f"Error interno: {e}", 500)
            except Exception:
                pass

    def manejar_subida_video(self):
        content_type = self.headers.get("Content-Type", "")
        if "multipart/form-data" not in content_type:
            self.enviar_error_json("Se esperaba multipart/form-data.", 400)
            return

        m = re.search(r'boundary=("?)([^";]+)\1', content_type)
        if not m:
            self.enviar_error_json("Petición multipart mal formada (sin boundary).", 400)
            return
        boundary = m.group(2).encode("utf-8")

        longitud = int(self.headers.get("Content-Length", 0))
        limite_bytes = LIMITE_TAMANO_MB * 1024 * 1024
        if longitud > limite_bytes:
            # Hay que vaciar el socket igualmente o la conexión queda colgada
            self.rfile.read(longitud)
            self.enviar_error_json(f"El archivo supera el límite de {LIMITE_TAMANO_MB}MB.", 413)
            return
        if longitud <= 0:
            self.enviar_error_json("Cuerpo de la petición vacío.", 400)
            return

        cuerpo = self.rfile.read(longitud)

        try:
            campos, archivo_info = self._parsear_multipart(cuerpo, boundary)
        except ValueError as e:
            self.enviar_error_json(f"Error al leer el archivo: {e}", 400)
            return

        titulo = (campos.get("titulo") or "").strip()
        descripcion = (campos.get("descripcion") or "").strip()
        categoria = (campos.get("categoria") or "Otros").strip() or "Otros"
        autor = (campos.get("autor") or "Anónimo").strip() or "Anónimo"

        if not titulo:
            self.enviar_error_json("El título es obligatorio.", 400)
            return

        if not archivo_info or not archivo_info.get("filename"):
            self.enviar_error_json("No se envió ningún archivo.", 400)
            return

        nombre_original = archivo_info["filename"]
        extension = Path(nombre_original).suffix.lower()

        if extension not in EXTENSIONES_PERMITIDAS:
            self.enviar_error_json(
                f"Formato no permitido. Usa: {', '.join(sorted(EXTENSIONES_PERMITIDAS))}", 400
            )
            return

        video_id = uuid.uuid4().hex[:12]
        nombre_archivo = f"{video_id}{extension}"
        ruta_destino = VIDEOS_DIR / nombre_archivo

        with open(ruta_destino, "wb") as f:
            f.write(archivo_info["data"])

        tamano_mb = round(ruta_destino.stat().st_size / 1024 / 1024, 2)

        nuevo_video = {
            "id": video_id,
            "titulo": titulo,
            "descripcion": descripcion,
            "categoria": categoria,
            "autor": autor,
            "archivo": nombre_archivo,
            "tamano_mb": tamano_mb,
            "fecha": time.time(),
            "vistas": 0,
            "likes": 0,
        }

        datos = cargar_datos()
        datos.setdefault("videos", []).append(nuevo_video)
        guardar_datos(datos)

        self.enviar_json(nuevo_video, status=201)

    @staticmethod
    def _parsear_multipart(cuerpo, boundary):
        """
        Parser manual de multipart/form-data, sin dependencias externas
        ni el módulo 'cgi' (deprecado desde Python 3.11 y eliminado en 3.13).
        Devuelve (campos_texto: dict, archivo: dict|None)
        """
        delimitador = b"--" + boundary
        partes = cuerpo.split(delimitador)

        campos = {}
        archivo_info = None

        for parte in partes:
            parte = parte.strip(b"\r\n")
            if not parte or parte == b"--":
                continue

            if b"\r\n\r\n" not in parte:
                continue

            cabeceras_raw, contenido = parte.split(b"\r\n\r\n", 1)
            # El contenido puede traer un \r\n final propio del boundary, lo quitamos
            if contenido.endswith(b"\r\n"):
                contenido = contenido[:-2]

            cabeceras_texto = cabeceras_raw.decode("utf-8", errors="replace")
            disposicion = None
            for linea in cabeceras_texto.split("\r\n"):
                if linea.lower().startswith("content-disposition:"):
                    disposicion = linea
                    break

            if not disposicion:
                continue

            nombre_m = re.search(r'name="([^"]*)"', disposicion)
            filename_m = re.search(r'filename="([^"]*)"', disposicion)
            nombre_campo = nombre_m.group(1) if nombre_m else None

            if filename_m:
                # Es un campo de archivo
                archivo_info = {
                    "filename": filename_m.group(1),
                    "data": contenido,
                }
            elif nombre_campo:
                campos[nombre_campo] = contenido.decode("utf-8", errors="replace")

        return campos, archivo_info

    # ── DELETE ────────────────────────────────────────────────
    def do_DELETE(self):
        parsed = urlparse(self.path)
        ruta = unquote(parsed.path)

        try:
            m = re.match(r'^/api/videos/([a-zA-Z0-9]+)$', ruta)
            if m:
                video_id = m.group(1)
                datos = cargar_datos()
                videos = datos.get("videos", [])
                video = next((v for v in videos if v["id"] == video_id), None)
                if not video:
                    self.enviar_error_json("Vídeo no encontrado.", 404)
                    return

                ruta_archivo = VIDEOS_DIR / video["archivo"]
                if ruta_archivo.exists():
                    ruta_archivo.unlink()

                datos["videos"] = [v for v in videos if v["id"] != video_id]
                guardar_datos(datos)
                self.enviar_json({"ok": True})
                return

            self.enviar_error_json("Ruta no encontrada.", 404)

        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception as e:
            try:
                self.enviar_error_json(f"Error interno: {e}", 500)
            except Exception:
                pass

    # ── OPTIONS (CORS, por si acaso) ─────────────────────────
    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, DELETE, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()


# ── ARRANQUE ───────────────────────────────────────────────────
if __name__ == "__main__":
    ip_local = obtener_ip_local()
    print("=" * 56)
    print("  🎬  MIGUELASGO TUBE - Servidor local")
    print("=" * 56)
    print(f"  En este equipo:   http://localhost:{PUERTO}")
    print(f"  En tu red local:  http://{ip_local}:{PUERTO}")
    print("=" * 56)
    print("  Comparte la segunda URL con otros dispositivos")
    print("  conectados a la MISMA red WiFi para que puedan")
    print("  ver y subir vídeos también.")
    print("=" * 56)
    print("  Pulsa CTRL+C para detener el servidor.")
    print()

    servidor = ThreadingHTTPServer(("0.0.0.0", PUERTO), TubeHandler)
    try:
        servidor.serve_forever()
    except KeyboardInterrupt:
        print("\nServidor detenido.")
        servidor.shutdown()
