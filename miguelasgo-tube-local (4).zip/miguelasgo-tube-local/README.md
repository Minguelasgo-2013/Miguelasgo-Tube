# 🎬 Miguelasgo Tube

Tu propio YouTube casero, corriendo desde un pen drive en tu red local.
Sin Firebase, sin tarjetas de crédito, sin nube — todo vive en tu pen drive
y se sirve a cualquier dispositivo conectado a tu misma red WiFi.

---

## 📁 Estructura del proyecto

```
miguelasgo-tube-local/
├── iniciar.sh           ← doble clic para arrancar (Linux)
├── server.py             ← el servidor (alternativa manual)
├── data.json              ← se crea solo, aquí se guardan los datos de los vídeos
├── static/
│   └── index.html          ← el frontend (no lo abras directamente con doble clic)
└── videos/                 ← aquí se guardan los archivos de vídeo subidos
```

---

## 📥 Cómo descargarlo desde GitHub

```bash
git clone https://github.com/TU_USUARIO/miguelasgo-tube.git
cd miguelasgo-tube
python3 server.py
```

(Sustituye `TU_USUARIO` por tu nombre de usuario real de GitHub una
vez hayas subido el repositorio.)

> 📌 **Nota:** los archivos de vídeo (`videos/`) y los datos generados
> (`data.json`) **no se suben a GitHub** — están en `.gitignore` a
> propósito, porque GitHub no es un buen sitio para alojar vídeos
> pesados (límite de 100MB por archivo) y porque cada copia del
> proyecto debe tener sus propios vídeos locales. Al clonar el repo,
> esas carpetas empezarán vacías y se irán rellenando según subas
> contenido desde la propia web.

---

## 🚀 Cómo arrancarlo

### Requisitos

- Solo **Python 3** (ya lo tienes en tu equipo, versión 3.11.2).
- **No necesita pip, Flask, ni ningún paquete adicional.** El servidor
  usa exclusivamente la librería estándar de Python, así que funciona
  incluso en equipos restringidos (centros educativos, aulas Abalar,
  etc.) donde no tienes permisos de administrador para instalar nada.

### Opción A — Doble clic (recomendado)

1. Conecta el pen drive.
2. Entra en la carpeta `miguelasgo-tube-local`.
3. Haz doble clic en **`iniciar.sh`**.
   - Si tu gestor de archivos te pregunta qué hacer con el archivo,
     elige **"Ejecutar"** o **"Ejecutar en una terminal"**
     (no "Abrir con editor de texto").
   - Si no aparece esa opción, puede que necesites marcarlo como
     ejecutable una vez (clic derecho → Propiedades → Permisos →
     "Permitir ejecutar como programa"), o ejecutarlo una vez desde
     terminal con `chmod +x iniciar.sh`. Después de eso, el doble
     clic funcionará siempre.
4. Se abrirá una terminal con los logs del servidor y, a los 2
   segundos, tu navegador se abrirá solo en `http://localhost:8000`.
5. Para parar el servidor: cierra esa ventana de terminal o pulsa
   `Ctrl + C` dentro de ella.

### Opción B — Manual desde terminal

```bash
cd /media/usuario/99E5-6538/miguelasgo-tube-local
python3 server.py
```

Verás algo así:

```
========================================================
  🎬  MIGUELASGO TUBE - Servidor local
========================================================
  En este equipo:   http://localhost:8000
  En tu red local:  http://192.168.1.XX:8000
========================================================
```

- **En tu propio PC**: abre `http://localhost:8000` en el navegador.
- **Desde el móvil u otro PC en la misma WiFi**: abre la segunda URL
  (la de "En tu red local"), por ejemplo `http://192.168.1.XX:8000`.

Para detener el servidor, vuelve a la terminal y pulsa `Ctrl + C`.

---

## ⚠️ Cosas importantes que debes saber

- **Sin login**: cualquier persona conectada a tu red WiFi puede ver y subir
  vídeos. Es una decisión consciente para simplificar — si más adelante
  quieres restringir quién sube, podemos añadir un PIN.
- **El servidor debe estar encendido** para que los demás puedan ver la
  página. Si apagas el PC o cierras la terminal, deja de funcionar para
  todos (incluido tú).
- **La IP local puede cambiar** cada vez que te conectas a una red distinta
  (o a veces incluso en la misma red). Vuelve a mirar la terminal al
  arrancar para coger la URL correcta.
- **Límite de tamaño por vídeo**: 500MB (configurable en `server.py`,
  variable `LIMITE_TAMANO_MB`).
- **Formatos permitidos**: mp4, webm, mov, mkv, avi, ogg.
- Si tienes un **firewall activo** en tu PC, puede que tengas que
  permitir conexiones entrantes al puerto 8000 para que otros
  dispositivos de tu red puedan acceder.

---

## 🛠️ Funciones incluidas

- Subida real de archivos de vídeo (con barra de progreso)
- Grid de vídeos estilo YouTube, con miniatura generada automáticamente
- Buscador por título/descripción
- Filtro por categorías
- Reproductor con contador de visitas y likes
- Eliminar vídeos propios
- Tema claro/oscuro
- Indicador de "servidor conectado/desconectado" en la cabecera

---

## 🔧 Cómo cambiar el puerto o el límite de tamaño

Abre `server.py` y modifica estas líneas cerca del principio:

```python
LIMITE_TAMANO_MB = 500  # tamaño máximo por vídeo
PUERTO = 8000
```

---

## 💾 ¿Dónde están mis datos?

- Los **archivos de vídeo** están en la carpeta `videos/` dentro del pen.
- Los **metadatos** (título, descripción, vistas, likes) están en
  `data.json`, también en el pen. Puedes abrirlo con cualquier editor
  de texto si quieres echar un vistazo o hacer una copia de seguridad.

Como todo vive en el pen drive, puedes llevártelo a cualquier otro PC
con Python instalado y seguirá funcionando igual.
